import React from 'react';
import './commitsData.scss';

class CommitsData extends React.Component {
  render() {
    return (
      <div className="CommitsData">
        <h2>Commits Data</h2>
      </div>
    );
  }
}

export default CommitsData;